class Enemy : public Character {
public:



protected:



}